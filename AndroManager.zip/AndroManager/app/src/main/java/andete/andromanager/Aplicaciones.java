package andete.andromanager;

/**
 * Created by andete on 19/06/17.
 */

public class Aplicaciones {
    public String nombre;
    public String iconBase64;
    public String packages;

    public Aplicaciones(String nombre, String iconBase64, String packages) {
        this.nombre = nombre;
        this.iconBase64 = iconBase64;
        this.packages = packages;
    }
}
