package andete.andromanager;

/**
 * Created by andete on 13/06/17.
 */

public class Ficheros {
    public String nombre;
    public String tipo;

    public Ficheros(String nombre, String tipo) {
        this.nombre = nombre;
        this.tipo = tipo;
    }
}
