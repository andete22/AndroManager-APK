package andete.andromanager;

/**
 * Created by andete on 14/06/17.
 */

public enum TiposArgumentos {
    ls, download, touch, open, inputText, mute, pressBoton, darBaja;
}
